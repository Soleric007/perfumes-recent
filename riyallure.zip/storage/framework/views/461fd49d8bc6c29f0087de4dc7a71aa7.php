<?php if (isset($component)) { $__componentOriginal17a65f77eed04729ba6955a6d8bd44cc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal17a65f77eed04729ba6955a6d8bd44cc = $attributes; } ?>
<?php $component = App\View\Components\AdLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ad-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AdLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="main-content">

        <div class="page-content">
            <div class="container-fluid">

                <!-- start page title -->
                <div class="row">
                    <div class="col-12">
                        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                            <h4 class="mb-sm-0">Product Details</h4>

                            <div class="page-title-right">
                                <ol class="m-0 breadcrumb">
                                    <li class="breadcrumb-item"><a href="javascript: void(0);">Ecommerce</a></li>
                                    <li class="breadcrumb-item active">Product Details</li>
                                </ol>
                            </div>

                        </div>
                    </div>
                </div>
                <!-- end page title -->

                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="row gx-lg-5">
                                    <div class="mx-auto col-xl-4 col-md-8">
                                        <div class="product-img-slider sticky-side-div">
                                            <div class="p-2 rounded swiper product-thumbnail-slider bg-light">
                                                <div class="swiper-wrapper">
                                                    <div class="swiper-slide">
                                                        <img src="/storage/<?php echo e($product->image); ?>" alt=""
                                                            class="img-fluid d-block" />
                                                    </div>

                                                </div>

                                            </div>
                                            <!-- end swiper thumbnail slide -->

                                            <!-- end swiper nav slide -->
                                        </div>
                                    </div>
                                    <!-- end col -->

                                    <div class="col-xl-8">
                                        <div class="mt-5 mt-xl-0">
                                            <div class="d-flex">
                                                <div class="flex-grow-1">
                                                    <h4 class="text-2xl uppercase"><?php echo e($product->title); ?></h4>
                                                    <div class="flex-wrap gap-3 hstack">
                                                        <div class="text-muted">Published : <span
                                                                class="text-body fw-medium"><?php echo e($product->created_at); ?></span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="flex-shrink-0">
                                                    <div>
                                                        <a onclick="return confirm('Are you sure you want to delete this product?')" href="<?php echo e(route('admin.deleteProduct', $product->id)); ?>" class="text-white bg-red-600 hover:bg-red-400 btn btn-light"
                                                            data-bs-toggle="tooltip" data-bs-placement="top"
                                                            title="Delete">Delete Product</a>
                                                    </div>
                                                </div>
                                            </div>



                                            <div class="mt-4 row">
                                                <div class="col-lg-3 col-sm-6">
                                                    <div class="p-2 border border-dashed rounded">
                                                        <div class="d-flex align-items-center">
                                                            <div class="avatar-sm me-2">
                                                                <div
                                                                    class="bg-transparent rounded avatar-title text-success fs-24">
                                                                    <i class="ri-money-dollar-circle-fill"></i>
                                                                </div>
                                                            </div>
                                                            <div class="flex-grow-1">
                                                                <p class="mb-1 text-muted">Price :</p>
                                                                <h5 class="mb-0">$<?php echo e($product->price); ?></h5>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- end col -->
                                                <div class="col-lg-3 col-sm-6">
                                                    <div class="p-2 border border-dashed rounded">
                                                        <div class="d-flex align-items-center">
                                                            <div class="avatar-sm me-2">
                                                                <div
                                                                    class="bg-transparent rounded avatar-title text-success fs-24">
                                                                    <i class="ri-file-copy-2-fill"></i>
                                                                </div>
                                                            </div>
                                                            <div class="flex-grow-1">
                                                                <p class="mb-1 text-muted">No. of Orders :</p>
                                                                <h5 class="mb-0">2,234</h5>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- end col -->
                                                <div class="col-lg-3 col-sm-6">
                                                    <div class="p-2 border border-dashed rounded">
                                                        <div class="d-flex align-items-center">
                                                            <div class="avatar-sm me-2">
                                                                <div
                                                                    class="bg-transparent rounded avatar-title text-success fs-24">
                                                                    <i class="ri-stack-fill"></i>
                                                                </div>
                                                            </div>
                                                            <div class="flex-grow-1">
                                                                <p class="mb-1 text-muted">Available Stocks :</p>
                                                                <h5 class="mb-0"><?php echo e($product->stock); ?></h5>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- end col -->

                                            </div>


                                            <!-- end row -->

                                            <div class="mt-4 text-muted">
                                                <h5 class="fs-14">Description :</h5>
                                                <p><?php echo e($product->description); ?></p>
                                            </div>


                                            <!-- product-content -->


                                            <!-- end card body -->
                                        </div>
                                    </div>
                                    <!-- end col -->
                                </div>
                                <!-- end row -->
                            </div>
                            <!-- end card body -->
                        </div>
                        <!-- end card -->
                    </div>
                    <!-- end col -->
                </div>
                <!-- end row -->

            </div>
            <!-- container-fluid -->
        </div>
        <!-- End Page-content -->

        <footer class="footer">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-6">
                        <script>
                            document.write(new Date().getFullYear())
                        </script> © Velzon.
                    </div>
                    <div class="col-sm-6">
                        <div class="text-sm-end d-none d-sm-block">
                            Design & Develop by Themesbrand
                        </div>
                    </div>
                </div>
            </div>
        </footer>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal17a65f77eed04729ba6955a6d8bd44cc)): ?>
<?php $attributes = $__attributesOriginal17a65f77eed04729ba6955a6d8bd44cc; ?>
<?php unset($__attributesOriginal17a65f77eed04729ba6955a6d8bd44cc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal17a65f77eed04729ba6955a6d8bd44cc)): ?>
<?php $component = $__componentOriginal17a65f77eed04729ba6955a6d8bd44cc; ?>
<?php unset($__componentOriginal17a65f77eed04729ba6955a6d8bd44cc); ?>
<?php endif; ?>
<?php /**PATH C:\Users\CHINEX\Desktop\perfumes\resources\views/admin/pages/productdetails.blade.php ENDPATH**/ ?>