<?php if (isset($component)) { $__componentOriginal17a65f77eed04729ba6955a6d8bd44cc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal17a65f77eed04729ba6955a6d8bd44cc = $attributes; } ?>
<?php $component = App\View\Components\AdLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ad-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AdLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="main-content">
        <div class="page-content">
            <div class="container-fluid">
                <!-- start page title -->
                <div class="row">
                    <div class="col-12">
                        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                            <h4 class="mb-sm-0">Add Category</h4>
                            <div class="page-title-right">
                                <ol class="m-0 breadcrumb">
                                    <li class="breadcrumb-item"><a href="javascript: void(0);">Riyallure</a></li>
                                    <li class="breadcrumb-item active">Create Product</li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end page title -->

                <form method="POST" action="<?php echo e(route('admin.store.category')); ?>" id="createproduct-form" autocomplete="off" class="needs-validation" novalidate enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-lg-8">
                            <div class="card">
                                <div class="card-body">
                                    <div class="mb-3">
                                        <label class="form-label" for="product-title-input">Category Name</label>
                                        <input type="hidden" class="form-control" id="formAction" name="formAction" value="add">
                                        <input type="text" class="form-control" id="product-title-input" name="name" placeholder="Enter product title" required>
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p class="text-sm text-red-600"><?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="mb-3 text-end">
                                <button type="submit" class="btn btn-success w-sm">Submit</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <footer class="footer">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-6">
                        <script>document.write(new Date().getFullYear())</script> © Riyallure.
                    </div>
                    <div class="col-sm-6">
                        <div class="text-sm-end d-none d-sm-block">Design & Develop by Soleric</div>
                    </div>
                </div>
            </div>
        </footer>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal17a65f77eed04729ba6955a6d8bd44cc)): ?>
<?php $attributes = $__attributesOriginal17a65f77eed04729ba6955a6d8bd44cc; ?>
<?php unset($__attributesOriginal17a65f77eed04729ba6955a6d8bd44cc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal17a65f77eed04729ba6955a6d8bd44cc)): ?>
<?php $component = $__componentOriginal17a65f77eed04729ba6955a6d8bd44cc; ?>
<?php unset($__componentOriginal17a65f77eed04729ba6955a6d8bd44cc); ?>
<?php endif; ?>
<?php /**PATH C:\Users\CHINEX\Desktop\perfumes\resources\views/admin/pages/addcategory.blade.php ENDPATH**/ ?>