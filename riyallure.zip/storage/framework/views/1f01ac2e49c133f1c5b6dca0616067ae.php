<div class="cs_cart_card_wrap">
    <div class="cs_cart_card">
        <div class="cs_cart_card_head cs_gray_bg">
            <h3 class="mb-0 cs_fs_18 cs_semibold">Your Cart (<?php echo e(count(session('cart'))); ?>)</h3>
            <button class="cs_cart_close">Close</button>
        </div>
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <?php $total = 0 ?>
        <?php $__currentLoopData = (array) session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $total += $details['price'] * $details['quantity'] ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div class="cs_cart_card_body">
            <?php if(session('cart')): ?>
                <div class="cs_cart_card_body_in">

                    <ul class="cs_cart_card_list cs_mp_0">
                        <?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li data-id="<?php echo e($id); ?>">
                                <div class="cs_cart_card_item">
                                    <div class="cs_cart_card_item_left">
                                        <img src="/storage/<?php echo e($details['image']); ?>" alt="Product">
                                    </div>
                                    <div class="cs_cart_card_item_right">
                                        <h3 class="cs_fs_18 cs_medium uppercase"><?php echo e($details['name']); ?></h3>
                                        <div class="flex flex-col gap-2">
                                            <label for="quantity" class="text-xl">Quantity:</label>
                                            <input type="number" value="<?php echo e($details['quantity']); ?>"
                                                class="form-control quantity update-cart" />
                                        </div>
                                        <p class="mb-0"><?php echo e($details['quantity']); ?> x <span
                                                class="cs_primary_color cs_medium"> <?php echo e($details['price']); ?></span></p>
                                        <button class="cs_cart_card_item_remove remove-from-cart" type="button"><i
                                                class="fa-regular fa-circle-xmark"></i></button>
                                    </div>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </ul>
                <?php else: ?>
                    <p class="cs_empty_cart_text cs_fs_18 cs_medium">No items in your cart. Start shopping now.</p>
            <?php endif; ?>
        </div>
    </div>
    <div class="cs_cart_card_footer">
        <div class="cs_cart_card_subtotal">
            <span>Subtotal:</span>
            <span class="cs_primary_color cs_semibold">$<?php echo e($total); ?></span>
        </div>
        <a href="<?php echo e(route('cart')); ?>" class="cs_btn cs_style_2 cs_medium cs_type_1 w-100">
            <span>View Cart</span>
        </a>
        <div class="cs_height_10 cs_height_lg_10"></div>
        <a href="checkout.html" class="cs_btn cs_style_1 cs_medium cs_type_1 w-100">
            <span>Checkout</span>
        </a>
    </div>
</div>
<div class="cs_cart_overlay"></div>
</div>
<?php /**PATH C:\Users\CHINEX\Desktop\perfumes\resources\views/home/sections/cartmodal.blade.php ENDPATH**/ ?>