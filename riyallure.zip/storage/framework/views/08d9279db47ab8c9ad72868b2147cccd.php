<div class="container">
      <div class="cs_height_30 cs_height_lg_30"></div>
      <div class="cs_grid_5_column cs_iconbox_style_1_wrap">
        <div class="cs_grid_col">
          <div class="cs_iconbox cs_style_1 text-center cs_radius_6">
            <img src="/template/assets/images/icons/feature_icon_1.svg" alt="Icon">
            <p class="mb-0 cs_semibold">Quality Assurance</p>
          </div>
        </div>
        <div class="cs_grid_col">
          <div class="cs_iconbox cs_style_1 text-center cs_radius_6">
            <img src="/template/assets/images/icons/feature_icon_2.svg" alt="Icon">
            <p class="mb-0 cs_semibold">Customer Satisfaction</p>
          </div>
        </div>
        <div class="cs_grid_col">
          <div class="cs_iconbox cs_style_1 text-center cs_radius_6">
            <img src="/template/assets/images/icons/feature_icon_3.svg" alt="Icon">
            <p class="mb-0 cs_semibold">Trust and Reliability</p>
          </div>
        </div>
        <div class="cs_grid_col">
          <div class="cs_iconbox cs_style_1 text-center cs_radius_6">
            <img src="/template/assets/images/icons/feature_icon_4.svg" alt="Icon">
            <p class="mb-0 cs_semibold">Personalization</p>
          </div>
        </div>
        <div class="cs_grid_col">
          <div class="cs_iconbox cs_style_1 text-center cs_radius_6">
            <img src="/template/assets/images/icons/feature_icon_5.svg" alt="Icon">
            <p class="mb-0 cs_semibold">Continuous Improvement</p>
          </div>
        </div>
      </div>
      <div class="cs_height_140 cs_height_lg_70"></div>
    </div><?php /**PATH C:\Users\CHINEX\Desktop\perfumes\resources\views/home/sections/features.blade.php ENDPATH**/ ?>