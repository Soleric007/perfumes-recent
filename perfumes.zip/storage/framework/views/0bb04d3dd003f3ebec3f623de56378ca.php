<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Order Details</title>
    <style>
        /* Custom styling for the PDF */
        body {
            font-family: Arial, sans-serif;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 8px;
        }

        th {
            background-color: #f2f2f2;
        }

        h2,
        h4 {
            margin-top: 0;
        }
    </style>
</head>

<body>
    <h2>Order Details - #<?php echo e($order->id); ?></h2>
    <p><strong>Name:</strong> <?php echo e($order->first_name); ?> <?php echo e($order->last_name); ?></p>
    <p><strong>Email:</strong> <?php echo e($order->email); ?></p>
    <p><strong>Phone:</strong> <?php echo e($order->phone); ?></p>
    <p><strong>Address:</strong> <?php echo e($order->address); ?>, <?php echo e($order->city); ?>, <?php echo e($order->state); ?>, <?php echo e($order->country); ?>

    </p>
    <p><strong>Total Amount:</strong> $<?php echo e(number_format($order->total_amount, 2)); ?></p>
    <br>
    <h4>Order Items:</h4>
    <table>
        <thead>
            <tr>
                <th>Product</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->product->title); ?></td>
                    <td><?php echo e($item->quantity); ?></td>
                    <td>$<?php echo e(number_format($item->price, 2)); ?></td>
                    <td>$<?php echo e(number_format($item->price * $item->quantity, 2)); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>

</html>
<?php /**PATH C:\Users\CHINEX\Desktop\perfumes\resources\views/orders/pdf.blade.php ENDPATH**/ ?>