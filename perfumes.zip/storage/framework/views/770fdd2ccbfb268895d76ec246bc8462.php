<section>
      <div class="container">
        <div class="cs_hero cs_style_1 cs_bg_filed cs_radius_30" data-src="/template/assets/images/herom.png">
          <div class="cs_hero_text">
            <h1 class="cs_hero_title cs_white_color cs_fs_100">Discover Your Fragrance</h1>
            <p class="cs_hero_subtitle cs_fs_24">Shop the Best Perfume Products Online</p>
            <a href="<?php echo e(route('shop.show')); ?>" id="shopper" class="cs_btn cs_style_1 cs_fs_18 cs_medium">Shop Now</a>
          </div>
          <div class="cs_hero_mini_img"><img class="topPef" src="/template/assets/images/heromini.png" alt="Hero Mini"></div>
        </div>
        <div class="cs_height_60 cs_height_lg_40"></div>

      </div>
    </section>
<?php /**PATH C:\Users\CHINEX\Desktop\perfumes\resources\views/home/sections/herosection.blade.php ENDPATH**/ ?>