<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>New Order Notification</title>
</head>

<body>
    <h2>New Order Placed</h2>
    <p>An order has been placed by <?php echo e($order->first_name); ?> <?php echo e($order->last_name); ?>.</p>
    <p><strong>Order ID:</strong> <?php echo e($order->id); ?></p>
    <p><strong>Total Amount:</strong> N<?php echo e(number_format($order->total_amount, 2)); ?></p>
    <p><strong>Email:</strong> <?php echo e($order->email); ?></p>
    <p><strong>Phone:</strong> <?php echo e($order->phone); ?></p>
    <p><strong>Address:</strong> <?php echo e($order->address); ?>, <?php echo e($order->city); ?>, <?php echo e($order->state); ?>, <?php echo e($order->country); ?>

    </p>

    <h4>Order Items:</h4>
    <ul>
        <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($item->product->title); ?> (Quantity: <?php echo e($item->quantity); ?>, Price:
                N<?php echo e(number_format($item->price, 2)); ?>)</li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</body>

</html>
<?php /**PATH C:\Users\CHINEX\Desktop\perfumes\resources\views/emails/order_placed.blade.php ENDPATH**/ ?>