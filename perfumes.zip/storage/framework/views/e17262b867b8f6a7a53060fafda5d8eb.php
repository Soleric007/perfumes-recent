<!DOCTYPE html>
<html>
<head>
    <title>Riyallure.com.ng</title>
</head>
<body>
    <h1 class="text-2xl font-bold uppercase">Message from: <?php echo e($mailData['email']); ?></h1>
    <h1 class="text-xl font-semibold">Hi, My name is <?php echo e($mailData['name']); ?></h1>
    <h1 class="text-lg">Hi, My name is <?php echo e($mailData['name']); ?></h1>
    <p>Message: <?php echo e($mailData['message']); ?></p>
</body>
</html>
<?php /**PATH C:\Users\CHINEX\Desktop\perfumes\resources\views/emails/contactMail.blade.php ENDPATH**/ ?>