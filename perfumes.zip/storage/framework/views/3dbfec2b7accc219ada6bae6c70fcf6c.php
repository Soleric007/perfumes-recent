<!DOCTYPE html>
<html>

<head>
    <title>Order Confirmation</title>
</head>

<body>
    <h1>Thank you for your order!</h1>
    <p>Hello <?php echo e($order->first_name); ?>,</p>
    <p>We have received your order with the following details:</p>

    <p><strong>Order ID:</strong> <?php echo e($order->id); ?></p>
    <p><strong>Total Amount:</strong> N<?php echo e($order->total_amount); ?></p>
    <p><strong>Payment Method:</strong> <?php echo e($order->payment_method); ?></p>

    <p>We will notify you once your order is shipped.</p>

    <p>Thank you for shopping with us!</p>
</body>

</html>
<?php /**PATH C:\Users\CHINEX\Desktop\perfumes\resources\views/emails/customer_order_notification.blade.php ENDPATH**/ ?>