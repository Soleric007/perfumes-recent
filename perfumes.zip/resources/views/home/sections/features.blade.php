<div class="container">
      <div class="cs_height_30 cs_height_lg_30"></div>
      
      <div class="cs_height_140 cs_height_lg_70"></div>
    </div>
